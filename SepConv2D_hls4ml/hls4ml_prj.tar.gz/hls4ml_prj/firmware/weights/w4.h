//Numpy array shape [1, 1, 1, 2]
//Min 1.000000000000
//Max 1.000000000000
//Number of zeros 0

#ifndef W4_H_
#define W4_H_

#ifndef __SYNTHESIS__
weight4_t w4[2];
#else
weight4_t w4[2] = {1.0, 1.0};
#endif

#endif
