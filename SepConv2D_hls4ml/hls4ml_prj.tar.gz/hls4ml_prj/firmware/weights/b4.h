//Numpy array shape [2]
//Min 0.000000000000
//Max 0.000000000000
//Number of zeros 2

#ifndef B4_H_
#define B4_H_

#ifndef __SYNTHESIS__
bias4_t b4[2];
#else
bias4_t b4[2] = {0, 0};
#endif

#endif
