#ifndef NNET_INSTR_GEN_H_
#define NNET_INSTR_GEN_H_

#include "nnet_helpers.h"
#include <iostream>

namespace nnet {

template <class data_T, typename CONFIG_T> class FillConv1DBuffer {
  public:
    static void fill_buffer(data_T data[CONFIG_T::in_width * CONFIG_T::n_chan],
                            data_T buffer[CONFIG_T::n_pixels][CONFIG_T::filt_width * CONFIG_T::n_chan],
                            const unsigned partition) {
        // To be implemented in subclasses
    }
};

template <class data_T, typename CONFIG_T> class FillConv2DBuffer {
  public:
    static void
    fill_buffer(data_T data[CONFIG_T::in_height * CONFIG_T::in_width * CONFIG_T::n_chan],
                data_T buffer[CONFIG_T::n_pixels][CONFIG_T::filt_height * CONFIG_T::filt_width * CONFIG_T::n_chan],
                const unsigned partition) {
        // To be implemented in subclasses
    }
};

// hls4ml insert code
template<class data_T, typename CONFIG_T>
class fill_buffer_2 : public FillConv2DBuffer<data_T, CONFIG_T> {
    public:
    static void fill_buffer(
        data_T data[CONFIG_T::in_height * CONFIG_T::in_width * CONFIG_T::n_chan],
        data_T buffer[CONFIG_T::n_pixels][CONFIG_T::filt_height * CONFIG_T::filt_width * CONFIG_T::n_chan],
        const unsigned partition
    ) {
        if (partition ==   0) {
            buffer[0][0] =    data[0]; buffer[0][1] =    data[1]; buffer[0][2] =    data[2]; buffer[0][3] =    data[6]; buffer[0][4] =    data[7]; buffer[0][5] =    data[8]; buffer[0][6] =   data[12]; buffer[0][7] =   data[13]; buffer[0][8] =   data[14];
            buffer[1][0] =    data[1]; buffer[1][1] =    data[2]; buffer[1][2] =    data[3]; buffer[1][3] =    data[7]; buffer[1][4] =    data[8]; buffer[1][5] =    data[9]; buffer[1][6] =   data[13]; buffer[1][7] =   data[14]; buffer[1][8] =   data[15];
            buffer[2][0] =    data[2]; buffer[2][1] =    data[3]; buffer[2][2] =    data[4]; buffer[2][3] =    data[8]; buffer[2][4] =    data[9]; buffer[2][5] =   data[10]; buffer[2][6] =   data[14]; buffer[2][7] =   data[15]; buffer[2][8] =   data[16];
            buffer[3][0] =    data[3]; buffer[3][1] =    data[4]; buffer[3][2] =    data[5]; buffer[3][3] =    data[9]; buffer[3][4] =   data[10]; buffer[3][5] =   data[11]; buffer[3][6] =   data[15]; buffer[3][7] =   data[16]; buffer[3][8] =   data[17];
            buffer[4][0] =    data[6]; buffer[4][1] =    data[7]; buffer[4][2] =    data[8]; buffer[4][3] =   data[12]; buffer[4][4] =   data[13]; buffer[4][5] =   data[14]; buffer[4][6] =   data[18]; buffer[4][7] =   data[19]; buffer[4][8] =   data[20];
            buffer[5][0] =    data[7]; buffer[5][1] =    data[8]; buffer[5][2] =    data[9]; buffer[5][3] =   data[13]; buffer[5][4] =   data[14]; buffer[5][5] =   data[15]; buffer[5][6] =   data[19]; buffer[5][7] =   data[20]; buffer[5][8] =   data[21];
            buffer[6][0] =    data[8]; buffer[6][1] =    data[9]; buffer[6][2] =   data[10]; buffer[6][3] =   data[14]; buffer[6][4] =   data[15]; buffer[6][5] =   data[16]; buffer[6][6] =   data[20]; buffer[6][7] =   data[21]; buffer[6][8] =   data[22];
            buffer[7][0] =    data[9]; buffer[7][1] =   data[10]; buffer[7][2] =   data[11]; buffer[7][3] =   data[15]; buffer[7][4] =   data[16]; buffer[7][5] =   data[17]; buffer[7][6] =   data[21]; buffer[7][7] =   data[22]; buffer[7][8] =   data[23];
            buffer[8][0] =   data[12]; buffer[8][1] =   data[13]; buffer[8][2] =   data[14]; buffer[8][3] =   data[18]; buffer[8][4] =   data[19]; buffer[8][5] =   data[20]; buffer[8][6] =   data[24]; buffer[8][7] =   data[25]; buffer[8][8] =   data[26];
            buffer[9][0] =   data[13]; buffer[9][1] =   data[14]; buffer[9][2] =   data[15]; buffer[9][3] =   data[19]; buffer[9][4] =   data[20]; buffer[9][5] =   data[21]; buffer[9][6] =   data[25]; buffer[9][7] =   data[26]; buffer[9][8] =   data[27];
            buffer[10][0] =   data[14]; buffer[10][1] =   data[15]; buffer[10][2] =   data[16]; buffer[10][3] =   data[20]; buffer[10][4] =   data[21]; buffer[10][5] =   data[22]; buffer[10][6] =   data[26]; buffer[10][7] =   data[27]; buffer[10][8] =   data[28];
            buffer[11][0] =   data[15]; buffer[11][1] =   data[16]; buffer[11][2] =   data[17]; buffer[11][3] =   data[21]; buffer[11][4] =   data[22]; buffer[11][5] =   data[23]; buffer[11][6] =   data[27]; buffer[11][7] =   data[28]; buffer[11][8] =   data[29];

        }
    }
};

} // namespace nnet

#endif
