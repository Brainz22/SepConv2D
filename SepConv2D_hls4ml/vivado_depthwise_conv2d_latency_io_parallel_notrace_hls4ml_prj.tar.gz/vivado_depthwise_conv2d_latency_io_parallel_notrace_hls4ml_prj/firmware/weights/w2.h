//Numpy array shape [3, 3, 1, 1]
//Min 1.000000000000
//Max 1.000000000000
//Number of zeros 0

#ifndef W2_H_
#define W2_H_

#ifndef __SYNTHESIS__
weight2_t w2[9];
#else
weight2_t w2[9] = {1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0};
#endif

#endif
