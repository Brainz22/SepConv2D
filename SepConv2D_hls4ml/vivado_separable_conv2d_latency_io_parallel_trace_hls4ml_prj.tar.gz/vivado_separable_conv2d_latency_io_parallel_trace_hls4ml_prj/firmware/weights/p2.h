//Numpy array shape [1, 1, 1, 2]
//Min 1.000000000000
//Max 1.000000000000
//Number of zeros 0

#ifndef P2_H_
#define P2_H_

#ifndef __SYNTHESIS__
pointwise2_t p2[2];
#else
pointwise2_t p2[2] = {1.0, 1.0};
#endif

#endif
