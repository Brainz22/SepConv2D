//Numpy array shape [1]
//Min 0.000000000000
//Max 0.000000000000
//Number of zeros 1

#ifndef Z2_H_
#define Z2_H_

#ifndef __SYNTHESIS__
zero_bias2_t z2[1];
#else
zero_bias2_t z2[1] = {0};
#endif

#endif
